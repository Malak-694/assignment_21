#include "cpu.h"

cpu::cpu() {}
