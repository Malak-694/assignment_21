#ifndef CPU_H
#define CPU_H


class cpu
{
public:
    cpu();
};

#endif // CPU_H
