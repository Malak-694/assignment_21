/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLineEdit *first;
    QLineEdit *second;
    QPushButton *show;
    QPushButton *copy;
    QPushButton *load1;
    QPushButton *add;
    QPushButton *jump;
    QPushButton *pushButton_7;
    QPushButton *load2;
    QLabel *regis;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLineEdit *third;
    QPlainTextEdit *registerlabel;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(494, 600);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        first = new QLineEdit(centralwidget);
        first->setObjectName("first");
        first->setGeometry(QRect(30, 40, 81, 16));
        second = new QLineEdit(centralwidget);
        second->setObjectName("second");
        second->setGeometry(QRect(120, 40, 81, 16));
        show = new QPushButton(centralwidget);
        show->setObjectName("show");
        show->setGeometry(QRect(99, 150, 91, 21));
        copy = new QPushButton(centralwidget);
        copy->setObjectName("copy");
        copy->setGeometry(QRect(99, 180, 91, 21));
        load1 = new QPushButton(centralwidget);
        load1->setObjectName("load1");
        load1->setGeometry(QRect(99, 90, 91, 21));
        add = new QPushButton(centralwidget);
        add->setObjectName("add");
        add->setGeometry(QRect(99, 210, 91, 21));
        jump = new QPushButton(centralwidget);
        jump->setObjectName("jump");
        jump->setGeometry(QRect(99, 240, 91, 21));
        pushButton_7 = new QPushButton(centralwidget);
        pushButton_7->setObjectName("pushButton_7");
        pushButton_7->setGeometry(QRect(99, 270, 91, 21));
        load2 = new QPushButton(centralwidget);
        load2->setObjectName("load2");
        load2->setGeometry(QRect(99, 120, 91, 21));
        regis = new QLabel(centralwidget);
        regis->setObjectName("regis");
        regis->setGeometry(QRect(450, 70, 231, 261));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(30, 20, 81, 20));
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(120, 20, 81, 16));
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(70, 70, 121, 20));
        label_5 = new QLabel(centralwidget);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(300, 10, 41, 14));
        label_6 = new QLabel(centralwidget);
        label_6->setObjectName("label_6");
        label_6->setGeometry(QRect(210, 20, 81, 20));
        third = new QLineEdit(centralwidget);
        third->setObjectName("third");
        third->setGeometry(QRect(210, 40, 81, 16));
        registerlabel = new QPlainTextEdit(centralwidget);
        registerlabel->setObjectName("registerlabel");
        registerlabel->setGeometry(QRect(300, 30, 181, 291));
        registerlabel->setReadOnly(true);
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 494, 19));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        show->setText(QCoreApplication::translate("MainWindow", "show", nullptr));
        copy->setText(QCoreApplication::translate("MainWindow", "copy", nullptr));
        load1->setText(QCoreApplication::translate("MainWindow", "load to memory", nullptr));
        add->setText(QCoreApplication::translate("MainWindow", "add", nullptr));
        jump->setText(QCoreApplication::translate("MainWindow", "jump", nullptr));
        pushButton_7->setText(QCoreApplication::translate("MainWindow", "run", nullptr));
        load2->setText(QCoreApplication::translate("MainWindow", "load to register", nullptr));
        regis->setText(QString());
        label_2->setText(QCoreApplication::translate("MainWindow", "Enter operand1:", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "Enter operand2", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "what do you want to do:", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "registers:", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "Enter operand3", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
