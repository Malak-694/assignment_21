#include <iostream>
#include"Bigreal.h"
using namespace std;
int main() {
    Bigreal n(5.1111111111111111);
    Bigreal b(10.00000000000000);
    n.print();
    return 0;
}
