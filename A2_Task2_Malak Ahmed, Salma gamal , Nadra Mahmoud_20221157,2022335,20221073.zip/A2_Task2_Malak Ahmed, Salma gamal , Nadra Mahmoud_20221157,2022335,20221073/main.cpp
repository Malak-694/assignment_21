
#include <iostream>
#include <fstream>
#include <cstring>
#include <vector>
#include <bits/stdc++.h>
#include "Bigreal.h"
using namespace std;
int main(){

}