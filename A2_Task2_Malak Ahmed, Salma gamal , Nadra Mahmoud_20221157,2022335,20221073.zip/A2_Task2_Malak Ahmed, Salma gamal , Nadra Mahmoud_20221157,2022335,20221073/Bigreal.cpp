// FCAI – OOP Programming – 2023 - Assignment 2
// File: Bigreal _Task2_S20,19_20220355_20221157_20221073_first submission.cpp
// Purpose: New data type ( Bigreal) .
// Author and ID: Nadra Mahmoud Saad 20220355 oshasaad968@gmail.com
// Author and ID: Salma Gamal 20221073
// Author and ID: Malak Ahmed  20221157
// Section: S20,19
// TA: Mohamed Talat
// Date: 5 Nov 2023
#include "Bigreal.h"
#include <bits/stdc++.h>
#include <stack>
//validation function that stop the program if the number Invalid .

bool Bigreal::isValidReal(string realNumber) {
    // set 3 counters to count sigms doits  and digets .
    int count_sign =0, count_doits =0 , count_digets =0 ;
    // looping on the string and increment the counters if the condition occur
    for(int i=0 ;i<realNumber.size();i++)
    { if(realNumber[i]=='.')
            count_doits++;
        else if(realNumber[i]=='-'|| realNumber[i]=='+' )
            count_sign++;
        else if(isdigit(realNumber[i]) )
            count_digets++;
        else
            return false;
    }
    // count_sign>1 or count_doits>1 or count_digets=0 the number Invalid .
    if( count_sign>1||count_doits>1 || count_digets==0)
        return false;
        // chick the position of sign (must e first)
    else if (count_sign==1){
        if ((realNumber[0]!= '+' ) && (realNumber[0]!= '-') )

            return false;

    }
    // if  the number valid return true
    return true;

}

Bigreal :: Bigreal (double real ){
    // change the double into string to store it .

    string real_number = to_string(real);

    // if the  real number not valid that lead to runtime error .

    if( ! isValidReal (real_number) )
        throw runtime_error("Not a valid real number .");

    // take the integer part from the string and store it in member variable integer .

    int c= std::count(real_number.begin(), real_number.end(),'.');
    if( c== 1){
        // take the integer part from the string and store it in member variable integer .
        for(int i=0 ; i< real_number.find('.');i++){
            // we start counting from pos 0 that may include the sign, and we want integer part only .
            if( (real_number[i] =='+' ||real_number[i] =='-' ))
                continue;
            integer.push_back(real_number[i]);
        }
        // take the fraction part from the string and store it in member variable fraction .

        for(int i=real_number.find('.')+1;i<real_number.size();i++){
            fraction.push_back(real_number[i]);
        }

        // if the num hasnot a integer part
        if(integer.size()==0)
            integer='0';
            // if the num hasnot a fraction part
        else if (fraction.size()==0)
            fraction='0';
    }
    else{

        for(int i=0 ; i< real_number.size();i++){
            // we start counting from pos 0 that may include the sign, and we want integer part only .
            if( (real_number[i] =='+' ||real_number[i] =='-' ))
                continue;
            integer.push_back(real_number[i]);
        } // if the num hasnot a fraction part
        fraction="000";
    }
    // set a value to boolean member variable .
    if ( real_number[0]=='+')
        sign = true;
    else if ( real_number[0]!='+' && real_number[0]!='-' )
        sign= true;
    else
        sign= false;

}
/



// parametrized constructor that take a string as a parameter  .

Bigreal:: Bigreal (string realNumber) {

    // if the  real number not valid that lead to runtime error .

    if (!isValidReal(realNumber))

        throw runtime_error("Not a valid real number .");

    int c= std::count(realNumber.begin(), realNumber.end(),'.');
    if( c== 1){
        // take the integer part from the string and store it in member variable integer .
        for(int i=0 ; i< realNumber.find('.');i++){
            // we start counting from pos 0 that may include the sign, and we want integer part only .
            if( (realNumber[i] =='+' ||realNumber[i] =='-' ))
                continue;
            integer.push_back(realNumber[i]);
        }
        // take the fraction part from the string and store it in member variable fraction .

        for(int i=realNumber.find('.')+1;i<realNumber.size();i++){
            fraction.push_back(realNumber[i]);
        }

        // if the num hasnot a integer part
        if(integer.size()==0)
            integer='0';
            // if the num hasnot a fraction part
        else if (fraction.size()==0)
            fraction='0';
    }
    else{

        for(int i=0 ; i< realNumber.size();i++){
            // we start counting from pos 0 that may include the sign, and we want integer part only .
            if( (realNumber[i] =='+' ||realNumber[i] =='-' ))
                continue;
            integer.push_back(realNumber[i]);
        }
        // if the num hasnot a fraction part
        fraction="000";
    }
    // set a value to boolean member variable .
    if ( realNumber[0]=='+')
        sign = true;
    else if ( realNumber[0]!='+' && realNumber[0]!='-' )
        sign= true;
    else
        sign= false;


}

// copy  constructor that copy object content to another .

Bigreal :: Bigreal (const Bigreal &other){

    integer = other.integer;
    fraction = other.fraction;
    sign = other.sign;
}

// overloading  assign operator that assign object content to another .

Bigreal &Bigreal::operator=(Bigreal const&other) {

    // this is a pointer that pointed to object content.
    Bigreal object = *this;
    integer = other.integer;
    fraction = other.fraction;
    sign = other.sign;

    //we return the content of the  pointer this .

    return *this;

}
// setter function if I want to set new value to the object .

void Bigreal::setNum(string realNumber) {

    // if the  real number not valid that lead to runtime error .

    if (!isValidReal(realNumber))

        throw runtime_error("Not a valid real number . ");

    // first I clear the member variable content to set anew values .
    integer.clear();
    fraction.clear();

    int c= std::count(realNumber.begin(), realNumber.end(),'.');
    if( c== 1){
        // take the integer part from the string and store it in member variable integer .
        for(int i=0 ; i< realNumber.find('.');i++){
            // we start counting from pos 0 that may include the sign, and we want integer part only .
            if( (realNumber[i] =='+' ||realNumber[i] =='-' ))
                continue;
            integer.push_back(realNumber[i]);
        }
        // take the fraction part from the string and store it in member variable fraction .

        for(int i=realNumber.find('.')+1;i<realNumber.size();i++){
            fraction.push_back(realNumber[i]);
        }

        // if the num hasnot a  integer part
        if(integer.size()==0)
            integer='0';
            // if the num hasnot a fraction part
        else if (fraction.size()==0)
            fraction='0';
    }
    else{

        for(int i=0 ; i< realNumber.size();i++){
            // we start counting from pos 0 that may include the sign, and we want integer part only .
            if( (realNumber[i] =='+' ||realNumber[i] =='-' ))
                continue;
            integer.push_back(realNumber[i]);
        }
        // if the num hasnot a fraction part
        fraction="000";
    }
    // set a value to boolean member variable .
    if ( realNumber[0]=='+')
        sign = true;
    else if ( realNumber[0]!='+' && realNumber[0]!='-' )
        sign= true;
    else
        sign= false;

}

// function to print the object .

void Bigreal::print() {
    char s;
    if (sign == 1)
        s = '+';
    else
        s = '-';
    cout << "number =" << s << integer <<"." << fraction << endl;

}

// function to get the sign of the real number .
char Bigreal::Number_sign() {

    if (sign == 1) {
        cout << "Sign of number is : ";
        return '+';
    } else
        cout << "Sign of number is : ";
    return '-';
}

//function to get the size of the real number .

int Bigreal::size() {
    cout << endl;

    // we add two to the sum of (integer , fraction) because of the sign and decimal point .

    int s = integer.size() + fraction.size() + 2 ;

    cout << "Size of number is : ";
    return s;

}

//000000
Bigreal Bigreal ::  operator+ (Bigreal const& n){

    Bigreal n3 ;
    Bigreal n2(n);

    stack <string > resultf; //save the fraction part
    long long carry=0;
    stack <string > result;//save the integer part


    //making the size of fractoin  the same
    if(fraction.size() > n2.fraction.size( )) n2.fraction.insert(n2.fraction.size(), fraction.size() - n2.fraction.size() , '0');
    else if (fraction.size() < n2.fraction.size( )) fraction.insert(fraction.size(), n2.fraction.size() - fraction.size() , '0');

    //making the size of integer  the same
    if(integer.size() > n2.integer.size( )) n2.integer.insert(0, integer.size() - n2.integer.size() , '0');
    else if (integer.size() < n2.integer.size( )) integer.insert(0, n2.integer.size() - integer.size() , '0');

    //desiding the sign of the result
    if (sign && n2.sign ) n3.sign=true;
    else if (!sign && n2.sign) n3.sign =false;
    else if (sign && !n2.sign){
        if(integer[0]>n2.integer[0]) n3.sign=true;
        else n3.sign =false;
    }
    else{
        if(integer[0]>n2.integer[0]) n3.sign =false;
        else n3.sign=true;

    }


    long long i, size= fraction.size();
    //the adding proces
    if(!sign&&!n2.sign || sign&&n2.sign) { // if both are positive or both are negative,
        // the procsess will be the same but the sign will defer


        for (i = size - 1; i >= 0; i--) {
            long long sum = (fraction[i] - 48) + (n2.fraction[i] - 48) + carry;
            if (sum > 9) {
                resultf.emplace(to_string((sum % 10)));
                carry = 1;
            } else {
                resultf.emplace(to_string(sum));
                carry = 0;
            }
        }
    }


    if(sign&&!n2.sign || !sign&&n2.sign) {
        //if the sign differ start from the big number to avoid failure in some test cases
        if (integer[0]>n2.integer[0]) {
            for (i = size - 1; i >= 0; i--) {
                long long sum = (fraction[i] - 48) - (n2.fraction[i] - 48);
                if (fraction[i] < n2.fraction[i]) {
                    sum = ((fraction[i] - 48) + 10) - (n2.fraction[i] - 48);
                    if(i-1<0) {
                        integer[integer.size()-1]-=1;
                    }else
                        fraction[i - 1] = fraction[i - 1] - 1;
                }
                resultf.emplace(to_string(sum));

            }
        }
        else{
            for (i = size - 1; i >= 0; i--) {
                long long sum = (n2.fraction[i] - 48) - (fraction[i] - 48);

                if (n2.fraction[i] < fraction[i]) {
                    sum = ((n2.fraction[i] - 48) + 10) - (fraction[i] - 48);
                    if(i-1<0) {
                        n2.integer[n2.integer.size()-1]-=1;
                    }else
                        n2.fraction[i - 1] = n2.fraction[i - 1] - 1;
                }
                resultf.emplace(to_string(sum));

            }
        }
    }

// copy the stack into string
    n3.fraction="";
    while(!resultf.empty()){
        n3.fraction.append(resultf.top());
        resultf.pop();

    }



    i=0,size= integer.size();
    //the adding proces
    if(!sign&&!n2.sign || sign&&n2.sign) {
        // if both are positive or both are negative,
        // the procsess will be the same but the sign will defer

        for (i = size - 1; i >= 0; i--) {
            long long sum = (integer[i] - 48) + (n2.integer[i] - 48) + carry;
            if (sum > 9) {
                result.emplace(to_string((sum % 10)));
                carry = 1;
            } else {
                result.emplace(to_string(sum));
                carry = 0;
            }
        }
        if(carry==1) result.emplace("1");
    }


    if(sign&&!n2.sign || !sign&&n2.sign) {
        //if the sign differ start from the big number to avoid failure in some test cases
        if (integer[0]>n2.integer[0]) {
            for (i = size - 1; i >= 0; i--) {
                long long sum = (integer[i] - 48) - (n2.integer[i] - 48);
                if (integer[i] < n2.integer[i]) {
                    sum = ((integer[i] - 48) + 10) - (n2.integer[i] - 48);
                    integer[i - 1] = integer[i - 1] - 1;
                }
                result.emplace(to_string(sum));

            }
        }
        else{
            for (i = size - 1; i >= 0; i--) {
                long long sum = (n2.integer[i] - 48) - (integer[i] - 48);

                if (n2.integer[i] < integer[i]) {
                    sum = ((n2.integer[i] - 48) + 10) - (integer[i] - 48);
                    n2.integer[i - 1] = n2.integer[i - 1] - 1;
                }
                result.emplace(to_string(sum));

            }
        }
    }


    while(result.top()=="0") result.pop();
// copy the stack into string
    while(!result.empty()){
        n3.integer.append(result.top());
        result.pop();


    }

    return n3;

}
//------
Bigreal Bigreal ::  operator- (Bigreal const& n){

    Bigreal n3 ;
    Bigreal n2(n);
    //the minus process is the adding process but change the sign of the second number
    if(n2.sign) n2.sign=false;
    else n2.sign=true;
    stack <string > resultf;
    long long carry=0;
    stack <string > result;


    //making the size the same
    if(fraction.size() > n2.fraction.size( )) n2.fraction.insert(n2.fraction.size(), fraction.size() - n2.fraction.size() , '0');
    else if (fraction.size() < n2.fraction.size( )) fraction.insert(fraction.size(), n2.fraction.size() - fraction.size() , '0');

    if(integer.size() > n2.integer.size( )) n2.integer.insert(0, integer.size() - n2.integer.size() , '0');
    else if (integer.size() < n2.integer.size( )) integer.insert(0, n2.integer.size() - integer.size() , '0');
    //desiding the sign of the result
    if (sign && n2.sign ) n3.sign=true;
    else if (!sign && n2.sign) n3.sign =false;
    else if (sign && !n2.sign){
        if(integer[0]>n2.integer[0]) n3.sign=true;
        else n3.sign =false;
    }
    else{
        if(integer[0]>n2.integer[0]) n3.sign =false;
        else n3.sign=true;

    }


    long long i, size= fraction.size();
    //the adding proces
    if(!sign&&!n2.sign || sign&&n2.sign) {
        // if both are positive or both are negative,
        // the procsess will be the same but the sign will defer
        for (i = size - 1; i >= 0; i--) {
            long long sum = (fraction[i] - 48) + (n2.fraction[i] - 48) + carry;
            if (sum > 9) {
                resultf.emplace(to_string((sum % 10)));
                carry = 1;
            } else {
                resultf.emplace(to_string(sum));
                carry = 0;
            }
        }
    }


    if(sign&&!n2.sign || !sign&&n2.sign) {
        //if the sign differ start from the big number to avoid failure in some test cases
        if (integer[0]>n2.integer[0]) {
            for (i = size - 1; i >= 0; i--) {
                long long sum = (fraction[i] - 48) - (n2.fraction[i] - 48);
                if (fraction[i] < n2.fraction[i]) {
                    sum = ((fraction[i] - 48) + 10) - (n2.fraction[i] - 48);
                    if(i-1<0) {
                        integer[integer.size()-1]-=1;
                    }else
                        fraction[i - 1] = fraction[i - 1] - 1;
                }
                resultf.emplace(to_string(sum));

            }
        }
        else{
            for (i = size - 1; i >= 0; i--) {
                long long sum = (n2.fraction[i] - 48) - (fraction[i] - 48);

                if (n2.fraction[i] < fraction[i]) {
                    sum = ((n2.fraction[i] - 48) + 10) - (fraction[i] - 48);
                    if(i-1<0) {
                        n2.integer[n2.integer.size()-1]-=1;
                    }else
                        n2.fraction[i - 1] = n2.fraction[i - 1] - 1;
                }
                resultf.emplace(to_string(sum));

            }
        }
    }

// copy the stack into string
    n3.fraction="";
    while(!resultf.empty()){
        n3.fraction.append(resultf.top());
        resultf.pop();

    }


    i=0,size= integer.size();
    //the adding proces
    if(!sign&&!n2.sign || sign&&n2.sign) {
        // if both are positive or both are negative,
        // the procsess will be the same but the sign will differ

        for (i = size - 1; i >= 0; i--) {
            long long sum = (integer[i] - 48) + (n2.integer[i] - 48) + carry;
            if (sum > 9) {
                result.emplace(to_string((sum % 10)));
                carry = 1;
            } else {
                result.emplace(to_string(sum));
                carry = 0;
            }
        }
        if(carry==1) result.emplace("1");
    }


    if(sign&&!n2.sign || !sign&&n2.sign) {
        //if the sign differ start from the big number to avoid failure in some test cases
        if (integer[0]>n2.integer[0]) {
            for (i = size - 1; i >= 0; i--) {
                long long sum = (integer[i] - 48) - (n2.integer[i] - 48);
                if (integer[i] < n2.integer[i]) {
                    sum = ((integer[i] - 48) + 10) - (n2.integer[i] - 48);
                    integer[i - 1] = integer[i - 1] - 1;
                }
                result.emplace(to_string(sum));

            }
        }
        else{
            for (i = size - 1; i >= 0; i--) {
                long long sum = (n2.integer[i] - 48) - (integer[i] - 48);

                if (n2.integer[i] < integer[i]) {
                    sum = ((n2.integer[i] - 48) + 10) - (integer[i] - 48);
                    n2.integer[i - 1] = n2.integer[i - 1] - 1;
                }
                result.emplace(to_string(sum));

            }
        }
    }


    while(result.top()=="0") result.pop();
// copy the stack into string
    while(!result.empty()){
        n3.integer.append(result.top());
        result.pop();


    }

    return n3;

}

bool Bigreal :: operator< (Bigreal anotherReal)
{  //we can use stod() function this convert string to a double value.
    return (stod(integer + "." + fraction) < stod(anotherReal.integer + "." + anotherReal.fraction));
}

bool Bigreal :: operator> (Bigreal anotherReal)
{  //we can use stod() function this convert string to a double value.
    return (stod(integer + "." + fraction) > stod(anotherReal.integer + "." + anotherReal.fraction));
}

bool Bigreal :: operator==(const Bigreal& anotherReal) const {
    //we can use stod() function this convert string to a double value.
    return stod(integer + "." + fraction) ==
           stod(anotherReal.integer + "." + anotherReal.fraction);
}

// The operator << is function overloaded stream insertion operator.
ostream& operator << (ostream& out, Bigreal num)
{
    // print the sign
    if (num.sign == -1)
    {
        out << '-';
    }
    // print the integar part
    out << num.integer;
    // print the fraction part if it exists
    if (!num.fraction.empty())
    {
        out << '.' << num.fraction;
    }
    return out;
}
