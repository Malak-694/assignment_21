
#include <iostream>
#ifndef UNTITLED12_BIGREAL_H
#define UNTITLED12_BIGREAL_H
using namespace std;

class Bigreal{
private:
    string integer;
    string fraction;
    bool sign;
    bool isValidReal (string realNumber) ;
public:
    Bigreal(double realNumber =0.0 );
    Bigreal (string realNumber);
    Bigreal (const Bigreal& other);
    Bigreal& operator= ( Bigreal const& other);
    void setNum (string realNumber);
    void print();
    int size();
    char Number_sign();
    Bigreal  operator+ (Bigreal const& n);
    Bigreal  operator- (Bigreal const& n);
    bool operator<(Bigreal anotherReal);
    bool operator>(Bigreal anotherReal);
    bool operator==(const Bigreal& anotherReal) const;
    friend ostream &operator<<(ostream &out, Bigreal num);
};


#endif